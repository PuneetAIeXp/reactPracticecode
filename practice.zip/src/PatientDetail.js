import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './PatientDetail.css'; // Add styles for the page

const PatientDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('/datas.json')
      .then(response => {
        const patientData = response.data.find(p => p.id === parseInt(id));
        if (patientData) {
          setPatient(patientData);
        } else {
          setError('Patient not found');
        }
        setLoading(false);
      })
      .catch(err => {
        setError('Error fetching data');
        setLoading(false);
      });
  }, [id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  const handleBack = () => {
    navigate('/');
  };

  return (
    <div className="patient-detail">
      <h2>{patient.name}</h2>
      <table className="patient-data-table">
        <thead>
          <tr>
            <th>Date</th>
            <th>Fasting</th>
            <th>Breakfast</th>
            <th>Lunch</th>
            <th>Dinner</th>
            <th>Bedtime</th>
            <th>Other</th>
          </tr>
        </thead>
        <tbody>
          {patient.data.map((dayData, index) => (
            <tr key={index}>
              <td>{dayData.Date}</td>
              <td>
                <div>Medication: {dayData.Fasting?.medication}</div>
                <div>Blood Glucose: {dayData.Fasting?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Fasting?.blood_pressure}</div>
                <div>Weight: {dayData.Fasting?.weight}</div>
                <div>Basal Insulin: {dayData.Fasting?.basal_insulin}</div>
              </td>
              <td>
                <div>Medication: {dayData.Breakfast?.medication}</div>
                <div>Blood Glucose: {dayData.Breakfast?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Breakfast?.blood_pressure}</div>
                <div>Weight: {dayData.Breakfast?.weight}</div>
                <div>Basal Insulin: {dayData.Breakfast?.basal_insulin}</div>
              </td>
              <td>
                <div>Medication: {dayData.Lunch?.medication}</div>
                <div>Blood Glucose: {dayData.Lunch?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Lunch?.blood_pressure}</div>
                <div>Weight: {dayData.Lunch?.weight}</div>
                <div>Basal Insulin: {dayData.Lunch?.basal_insulin}</div>
              </td>
              <td>
                <div>Medication: {dayData.Dinner?.medication}</div>
                <div>Blood Glucose: {dayData.Dinner?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Dinner?.blood_pressure}</div>
                <div>Weight: {dayData.Dinner?.weight}</div>
                <div>Basal Insulin: {dayData.Dinner?.basal_insulin}</div>
              </td>
              <td>
                <div>Medication: {dayData.Bedtime?.medication}</div>
                <div>Blood Glucose: {dayData.Bedtime?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Bedtime?.blood_pressure}</div>
                <div>Weight: {dayData.Bedtime?.weight}</div>
                <div>Basal Insulin: {dayData.Bedtime?.basal_insulin}</div>
              </td>
              <td>
                <div>Medication: {dayData.Other?.medication}</div>
                <div>Blood Glucose: {dayData.Other?.blood_glucose_level}</div>
                <div>Blood Pressure: {dayData.Other?.blood_pressure}</div>
                <div>Weight: {dayData.Other?.weight}</div>
                <div>Basal Insulin: {dayData.Other?.basal_insulin}</div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={handleBack} className="back-button">Back</button>
    </div>
  );
};

export default PatientDetail;
