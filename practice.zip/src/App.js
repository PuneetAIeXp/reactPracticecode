import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PatientList from './PatientList';
import PatientDetail from './PatientDetail';
import './App.css';

const App = () => {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    axios.get('./datas.json')
      .then(response => {
        setPatients(response.data);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<PatientList patients={patients} />} />
          <Route path="/patient/:id" element={<PatientDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
