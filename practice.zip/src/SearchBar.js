import React from 'react';
import './SearchBar.css'; // Add styles for the search bar

const SearchBar = ({ searchTerm, setSearchTerm }) => {
  return (
    <input
      type="text"
      className="search-bar"
      placeholder="Search by name"
      value={searchTerm}
      onChange={e => setSearchTerm(e.target.value)}
    />
  );
};

export default SearchBar;

