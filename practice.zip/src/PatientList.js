import React from 'react';
import { Link } from 'react-router-dom';
import './PatientList.css'; // Add styles for the list

const PatientList = ({ patients }) => {
  const sortedPatients = patients.sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div className="patient-list-container">
      <h1>Patient List</h1>
      <ul className="patient-list">
        {sortedPatients.map(patient => (
          <li key={patient.id} className="patient-list-item">
            <span>{patient.name}</span>
            <Link to={`/patient/${patient.id}`}>
              <button className="detail-button">Detail</button>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PatientList;
